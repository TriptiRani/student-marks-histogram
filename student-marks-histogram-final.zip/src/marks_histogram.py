import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

tripti_rani_data_path = Path(__file__).resolve().parents[1] / "data" / "marks.csv"
outputs_dir = Path(__file__).resolve().parents[1] / "outputs"
outputs_dir.mkdir(parents=True, exist_ok=True)

def load_and_clean(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    df.columns = [c.strip().lower() for c in df.columns]
    required = {"student_id", "subject", "marks"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV must have columns: {required}")
    df["marks"] = pd.to_numeric(df["marks"], errors="coerce")
    df = df.dropna(subset=["marks"]).copy()
    df = df[(df["marks"] >= 0) & (df["marks"] <= 100)].copy()
    df["subject"] = df["subject"].astype(str).str.strip().str.title()
    return df

def freedman_diaconis_bins(series: pd.Series) -> int:
    x = series.dropna().values
    if len(x) < 2:
        return 10
    iqr = np.subtract(*np.percentile(x, [75, 25]))
    if iqr == 0:
        return 10
    h = 2 * iqr * (len(x) ** (-1/3))
    if h == 0:
        return 10
    bins = int(np.ceil((x.max() - x.min()) / h))
    return max(bins, 5)

def plot_hist(series: pd.Series, title: str, save_path: Path):
    bins = freedman_diaconis_bins(series)
    plt.figure()
    plt.hist(series, bins=bins)
    plt.axvline(series.mean(), linestyle="--", linewidth=1.5, label=f"Mean: {series.mean():.1f}")
    plt.axvline(series.median(), linestyle="-.", linewidth=1.5, label=f"Median: {series.median():.1f}")
    plt.title(title)
    plt.xlabel("Marks")
    plt.ylabel("Frequency")
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()

def plot_pass_fail_bar(series: pd.Series, threshold: float, save_path: Path):
    passed = (series >= threshold).sum()
    failed = (series < threshold).sum()
    plt.figure()
    plt.bar(["Pass", "Fail"], [passed, failed])
    plt.title(f"Pass vs Fail (Threshold = {threshold})")
    plt.ylabel("Number of Students")
    plt.tight_layout()
    plt.savefig(save_path, dpi=200)
    plt.close()

def summary_stats(df: pd.DataFrame) -> pd.DataFrame:
    def stats(s: pd.Series) -> dict:
        return {
            "count": int(s.count()),
            "mean": float(s.mean()),
            "median": float(s.median()),
            "std": float(s.std(ddof=1)) if s.count() > 1 else 0.0,
            "min": float(s.min()),
            "max": float(s.max())
        }
    overall = pd.DataFrame([stats(df["marks"])], index=["OVERALL"])
    by_subj = (
        df.groupby("subject")["marks"]
          .apply(lambda s: pd.Series(stats(s)))
    )
    by_subj = by_subj.unstack(level=-1)
    out = pd.concat([overall, by_subj], axis=0)
    out.index.name = "group"
    return out.round(2)

def generate_insights(df: pd.DataFrame) -> list:
    lines = []
    s = df["marks"]
    lines.append(f"Overall average marks ≈ {s.mean():.1f}; median ≈ {s.median():.1f}.")
    pass_rate = (s >= 40).mean() * 100
    lines.append(f"Pass rate ≈ {pass_rate:.1f}% (threshold 40).")
    by_mean = df.groupby('subject')["marks"].mean().sort_values()
    worst = by_mean.index[0]
    best  = by_mean.index[-1]
    lines.append(f"Best average subject: {best}; Lowest average subject: {worst}.")
    high_cluster = (s.between(70, 90)).mean() * 100
    lines.append(f"~{high_cluster:.1f}% students are in the 70–90 range.")
    return lines

def main():
    df = load_and_clean(tripti_rani_data_path)
    plot_hist(df["marks"], "Distribution of Student Marks (Overall)", outputs_dir / "hist_overall.png")
    for subj, sdf in df.groupby("subject"):
        save_path = outputs_dir / f"hist_by_subject_{subj.replace(' ', '_')}.png"
        plot_hist(sdf["marks"], f"Distribution of Marks — {subj}", save_path)
    plot_pass_fail_bar(df["marks"], threshold=40, save_path=outputs_dir / "pass_fail_bar.png")
    stats_df = summary_stats(df)
    stats_df.to_csv(outputs_dir / "summary_stats.csv", index=False)
    insights = generate_insights(df)
    (outputs_dir / "insights.txt").write_text("\\n".join(f"- {line}" for line in insights), encoding="utf-8")
    print("Done. See outputs/.")

if __name__ == "__main__":
    main()